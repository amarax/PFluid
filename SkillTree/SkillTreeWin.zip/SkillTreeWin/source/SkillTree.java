import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.awt.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class SkillTree extends PApplet {




PFont font_label;
PFont font_value;

PFont font_TSW_Title;
PFont font_TSW_Subtitle;
PFont font_TSW_AbilityTree;
PFont font_TSW_AbilityName;
PFont font_TSW_AbilityDescription;


TSW_AbilityTree abilityTreeData;
TSW_WikiParser wikiParser;

TSW_UIControl_AbilityTree abilityTreeWidget;


ArrayList<UIControl> uiControls = new ArrayList();
UIControl hoveredControl = null;
UIControl activeControl = null;

Global_Boolean global_lineMode = new Global_Boolean( false );

Global_Float outerRingSize = new Global_Float( 360 );
Global_Float innerRingSize = new Global_Float( 100 );
Global_Float ringThickness = new Global_Float( 10 );
Global_Float abilityRingThickness = new Global_Float( 30 );
Global_Float branchGapSize = new Global_Float( 1 );
Global_Float abilityGapSize = new Global_Float( 0.5f );
Global_Float angleOffset = new Global_Float( 0 );
Global_Float selectedNodeRatio = new Global_Float( 0.8f );
Global_Boolean showAuxWheel = new Global_Boolean( true );
Global_Boolean sizeByPoints = new Global_Boolean( false );

boolean global_debug = false;


public void setup()
{




  size( 1440, 810 );
  smooth();
  colorMode( HSB, 360.0f, 1.0f, 1.0f, 1.0f );

  frameRate( 60 );

  font_label = loadFont( "HelveticaNeue-Bold-8.vlw" );
  font_value = loadFont( "HelveticaNeue-8.vlw" );

  font_TSW_Title = loadFont( "Futura-CondensedExtraBold-18.vlw" );
  font_TSW_Subtitle = loadFont( "Futura-Medium-18.vlw" );
  font_TSW_AbilityTree = loadFont( "Futura-Medium-12.vlw" );
  font_TSW_AbilityName = loadFont( "Futura-Medium-10.vlw" );
  font_TSW_AbilityDescription = loadFont( "CenturyGothic-9.vlw" );

  abilityTreeData = new TSW_AbilityTree();
  wikiParser = new TSW_WikiParser();
  wikiParser.populate( abilityTreeData ); 

  int tSize = 400;
  abilityTreeWidget = new TSW_UIControl_AbilityTree( abilityTreeData, new Rectangle( height / 2 - tSize + 100, height / 2 - tSize, tSize * 2, tSize * 2 ) );
  uiControls.add( abilityTreeWidget );


  int tYPos = 50;
  int tOffset = 50;

  tSize = 40;
  UIControl_Switch tModeSwitch = new UIControl_Switch( new Rectangle( width - tSize - 50, tYPos, tSize, 20 ) );
  tModeSwitch.setLabel( "Circle / Line" );
  uiControls.add( tModeSwitch );
  tYPos += tOffset + 25;

  tSize = 215;
  UIControl_Slider tInnerSizeSlider = new UIControl_Slider( 20, tSize * 2 + 20, new Rectangle( width - tSize - 50, tYPos, tSize, 12 ) );
  tInnerSizeSlider.setLabel( "Inner Ring Distance from Outer Ring" );
  uiControls.add( tInnerSizeSlider );
  tYPos += tOffset;

  tSize = 200;
  UIControl_Slider tArcThicknessSlider = new UIControl_Slider( 0, tSize/2, new Rectangle( width - tSize - 50, tYPos, tSize, 12 ) );
  tArcThicknessSlider.setLabel( "Branch Ring Thickness" );
  uiControls.add( tArcThicknessSlider );
  tYPos += tOffset;

  tSize = 200;
  UIControl_Slider tAbilityArcThicknessSlider = new UIControl_Slider( 0, tSize/2, new Rectangle( width - tSize - 50, tYPos, tSize, 12 ) );
  tAbilityArcThicknessSlider.setLabel( "Ability Ring Thickness" );
  uiControls.add( tAbilityArcThicknessSlider );
  tYPos += tOffset;

  tSize = 200;
  UIControl_Slider tGapSizeSlider = new UIControl_Slider( 0, 5, new Rectangle( width - tSize - 50, tYPos, tSize, 12 ) );
  tGapSizeSlider.setLabel( "Gap between Branches" );
  uiControls.add( tGapSizeSlider );
  tYPos += tOffset;

  tSize = 200;
  UIControl_Slider tAbilityGapSizeSlider = new UIControl_Slider( 0, 2, new Rectangle( width - tSize - 50, tYPos, tSize, 12 ) );
  tAbilityGapSizeSlider.setLabel( "Gap between Abilities" );
  uiControls.add( tAbilityGapSizeSlider );
  tYPos += tOffset;

  tSize = 200;
  UIControl_Slider tSelectionSizeSlider = new UIControl_Slider( 0, 0.9999f, new Rectangle( width - tSize - 50, tYPos, tSize, 12 ) );
  tSelectionSizeSlider.setLabel( "Selected Node Ratio (Size)" );
  uiControls.add( tSelectionSizeSlider );
  tYPos += tOffset;

  tSize = 40;
  UIControl_Switch tShowAuxWheel = new UIControl_Switch( new Rectangle( width - tSize - 50, tYPos, tSize, 20 ) );
  tShowAuxWheel.setLabel( "Aux Wheel" );
  uiControls.add( tShowAuxWheel );
  tYPos += tOffset;

  tSize = 40;
  UIControl_Switch tSizeByPoints = new UIControl_Switch( new Rectangle( width - tSize - 50, tYPos, tSize, 20 ) );
  tSizeByPoints.setLabel( "AP Width" );
  uiControls.add( tSizeByPoints );

//  tSize = 40;
//  UIControl_Switch tLengthByPoints = new UIControl_Switch( new Rectangle( width - tSize - 100, tYPos, tSize, 20 ) );
//  tLengthByPoints.setLabel( "AP Length" );
//  uiControls.add( tLengthByPoints );
  tYPos += tOffset;

  tSize = 215;
  UIControl_Slider tSizeSlider = new UIControl_Slider( 20, tSize * 2 + 20, new Rectangle( width - tSize - 50, tYPos, tSize, 12 ) );
  tSizeSlider.setLabel( "Outer Ring Size" );
  uiControls.add( tSizeSlider );
  tYPos += tOffset;

//  tSize = 400;
//  UIControl_Slider tAngleOffsetSlider = new UIControl_Slider( -PI, PI, new Rectangle( width - tSize - 50, tYPos, tSize, 12 ) );
//  tAngleOffsetSlider.setLabel( "Angle Offset" );
//  uiControls.add( tAngleOffsetSlider );
//  tYPos += tOffset;

  tModeSwitch.setup( global_lineMode );

  tSizeSlider.setup( outerRingSize );
  tInnerSizeSlider.setup( innerRingSize );
  tArcThicknessSlider.setup( ringThickness );
  tAbilityArcThicknessSlider.setup( abilityRingThickness );
  tGapSizeSlider.setup( branchGapSize );
  tAbilityGapSizeSlider.setup( abilityGapSize );
  tSelectionSizeSlider.setup( selectedNodeRatio );
  tShowAuxWheel.setup( showAuxWheel );
  tSizeByPoints.setup( sizeByPoints );
//  tAngleOffsetSlider.setup( angleOffset );

  abilityTreeWidget.setup();
}


public void draw()
{


  background( 0, 0, 0.15f );

  hoveredControl = null;
  for ( UIControl iUIControl : uiControls )
  {
    if ( iUIControl.isMouseIn() )
    {
      hoveredControl = iUIControl;
    }
  }

  // UPDATE LOOP
  for ( UIControl iUIControl : uiControls )
  {
    iUIControl.update();
  }


  // DRAW LOOP
  for ( UIControl iUIControl : uiControls )
  {
    iUIControl.draw();
  }
}

public void mousePressed()
{
  activeControl = hoveredControl;
  
  if( activeControl != null )
  {
    activeControl.onMousePressed();
  }
}

public void mouseReleased()
{
  if( activeControl == hoveredControl && activeControl != null )
  {
    activeControl.onMouseReleased();
  }

  activeControl = null;
}

class DampingHelper_Float
{
  float currentValue;
  float dampingFactor;
  
  DampingHelper_Float( float aDampingFactor, float aStartValue )
  {
    dampingFactor = aDampingFactor;
    currentValue = aStartValue;
  }
  
  public void update( float aActualValue )
  {
    currentValue += ( aActualValue - currentValue ) * dampingFactor;
  }
  
  public float getValue()
  {
    return currentValue;
  }

  public void setDampingFactor( float aDampingFactor )
  {
    dampingFactor = aDampingFactor;
  }
}

class DampingHelper_PVector
{
  DampingHelper_Float xDamper;
  DampingHelper_Float yDamper;
  
  DampingHelper_PVector( float aDampingFactor, PVector aStartValue )
  {
     xDamper = new DampingHelper_Float( aDampingFactor, aStartValue.x );
     yDamper = new DampingHelper_Float( aDampingFactor, aStartValue.y );
  }
  
  public void update( PVector aActualValue )
  {
    xDamper.update( aActualValue.x );
    yDamper.update( aActualValue.y );
  }
  
  public PVector getValue()
  {
    return new PVector( xDamper.getValue(), yDamper.getValue() );
  }
  
  public void setDampingFactor( float aDampingFactor )
  {
    xDamper.setDampingFactor( aDampingFactor );
    yDamper.setDampingFactor( aDampingFactor );
  }
}




class EasingHelper_Float
{
  float startValue; 
  float transitionTime;  // in seconds
  
  float currentValue;
  private int startTime;
  
  EasingHelper_Float( float aInitialValue )
  {
    startValue = aInitialValue;
    currentValue = aInitialValue;
    transitionTime = 0;
    startTime = 0;
  }
  
  public void start( float aStartValue, float aTransitionTime )
  {
    startValue = aStartValue;
    transitionTime = aTransitionTime;
    
    currentValue = startValue;
    startTime = millis();
  }
  
  public void update( float aActualValue )
  {
    float tCurrentTime = ( millis() - startTime ) / 1000.0f;
    
    float tFactor = sin( -HALF_PI + PI * ( tCurrentTime / transitionTime ) );
    tFactor = 0.5f * tFactor + 0.5f;
    tFactor = pow( tFactor, 1 );
   
    if( tCurrentTime < transitionTime )
    {
      currentValue = ( 1 - tFactor ) * startValue + tFactor * aActualValue;
    }
  }
  
  public float getValue()
  {
    return currentValue;
  }
}

class EasingHelper_PVector
{
  EasingHelper_Float xEaser;
  EasingHelper_Float yEaser;
  
  EasingHelper_PVector( PVector aInitialValue )
  {
    xEaser = new EasingHelper_Float( aInitialValue.x );
    yEaser = new EasingHelper_Float( aInitialValue.y );
  }
  
  public void start( PVector aStartValue, float aTransitionTime )
  {
    xEaser.start( aStartValue.x, aTransitionTime );
    yEaser.start( aStartValue.y, aTransitionTime );
  }
  
  public void update( PVector aActualValue )
  {
    xEaser.update( aActualValue.x );
    yEaser.update( aActualValue.y );
  }
  
  public PVector getValue()
  {
    return new PVector( xEaser.getValue(), yEaser.getValue() );
  }
}


public void pointcross( float aX, float aY, float aSize )
{
  line( aX, aY - aSize, aX, aY + aSize ); 
  line( aX - aSize, aY, aX + aSize, aY ); 
}

class Global_Float
{
  float value;
  
  public Global_Float( float aValue )
  {
    value = aValue;
  }
}



class Global_Boolean
{
  boolean value;
  
  public Global_Boolean( boolean aValue )
  {
    value = aValue;
  }
}


class Vector2
{
  float x;
  float y;
  
  public Vector2( float aX, float aY )
  {
    x = aX;
    y = aY;
  }
  
  public float distanceTo( float aX, float aY )
  {
    float tSquaredX = x - aX;
    tSquaredX *= tSquaredX;
    float tSquaredY = y - aY;
    tSquaredY *= tSquaredY;
    
    return sqrt( tSquaredX + tSquaredY );
  }
  
}


static class Angle
{
  /// Normalizes angles to between 0 to TWO_PI
  public static float normalize( float aAngle )
  {
    float tAngle = aAngle % TWO_PI;
    if( tAngle < 0 ) { tAngle += TWO_PI; }
    return tAngle;
  }
  
  public static boolean isWithinAngles( float aAngleToCheck, float aStartAngle, float aEndAngle )
  {
    float tAngleToCheck = Angle.normalize( aAngleToCheck );
    float tStartAngle = Angle.normalize( aStartAngle );
    float tEndAngle = Angle.normalize( aEndAngle );
    
    if( tEndAngle < tStartAngle )
    {
      if( tAngleToCheck >= ( tStartAngle - EPSILON ) && tAngleToCheck <= ( TWO_PI + EPSILON ) )
        return true;

      if( tAngleToCheck >= ( 0 - EPSILON ) && tAngleToCheck <= ( tEndAngle + EPSILON ) )
        return true;
    }

    if( tAngleToCheck >= ( tStartAngle - EPSILON ) && tAngleToCheck <= ( tEndAngle + EPSILON ) )
      return true;
    
    return false;
  }
  
  public static float calcMidAngle( float aStartAngle, float aEndAngle )
  {
    if( aEndAngle - aStartAngle < EPSILON)
    {
      return aStartAngle;
    }
    
    float tStartAngle = Angle.normalize( aStartAngle );
    float tEndAngle = Angle.normalize( aEndAngle );
    
    if( tStartAngle > tEndAngle )
    {
      return Angle.normalize( ( tStartAngle + tEndAngle + TWO_PI ) / 2.0f );
    }
    
    return ( ( tStartAngle + tEndAngle ) / 2.0f );
  }
}


public float min_abs( float aValue1, float aValue2 )
{
  if( abs( aValue1 ) <= abs( aValue2 ) )
  {
    return aValue1;
  }
  
  return aValue2;
}


public int signof( float aValue1 )
{
  if( aValue1 < 0 )
  {
    return -1;
  }
  
  return 1;
}

// Fix description appearance.
// Fix cirle/line mode transition.


// Experiment with motion blur.


class TSW_AbilityTree
{
  


  TSW_AbilityNode rootNode;
  ArrayList<TSW_Ability> abilities;
  
  int cLevels;
  
  public TSW_AbilityTree()
  {
    rootNode = new TSW_AbilityNode();
    abilities = new ArrayList<TSW_Ability>();
    
    cLevels = 0;
  }
  
  public void attachBranch( TSW_AbilityBranch aBranch, TSW_AbilityBranch aParentBranch )
  {
    TSW_AbilityNode tParent = rootNode;
    if( aParentBranch != null ) { tParent = aParentBranch; }
    
    aBranch.setParentNode( tParent );
    tParent.addChildNode( aBranch );
  }
  
  public void attachAbility( TSW_Ability aAbility, TSW_AbilityBranch aParentBranch )
  {
    abilities.add( aAbility );
    
    aAbility.setParentNode( aParentBranch );
    aParentBranch.addChildNode( aAbility );
  }

  public TSW_AbilityBranch addNewBranch( String aName, int aColor, TSW_AbilityBranch aParentBranch )
  {
    TSW_AbilityBranch tNewBranch = new TSW_AbilityBranch( aName );
    tNewBranch.nodeColor = aColor;
    this.attachBranch( tNewBranch, aParentBranch );
    
    return tNewBranch;
  }
  
  public TSW_Ability addNewAbility( String aName, int aPoints, int aLockedColor, int aUnlockedColor, TSW_AbilityBranch aParentBranch )
  {
    TSW_Ability tNewAbility = new TSW_Ability( aName, aPoints );
    tNewAbility.nodeLockedColor = aLockedColor;
    tNewAbility.nodeUnlockedColor = aUnlockedColor;
    tNewAbility.nodeColor = aLockedColor;
    this.attachAbility( tNewAbility, aParentBranch );
    
    return tNewAbility;
  }
}

class TSW_AbilityNode
{
  protected TSW_AbilityNode parentNode;
  protected ArrayList<TSW_AbilityNode> childNodes;
  
  String name;
  public int nodeColor;

  public TSW_UIControl_AbilityNode linkedControl;
  
  public TSW_AbilityNode()
  {
    childNodes = new ArrayList<TSW_AbilityNode>();
  }
  
  public void setParentNode( TSW_AbilityNode aParent )
  {
    parentNode = aParent;
  }
  
  public void addChildNode( TSW_AbilityNode aChild )
  {
    childNodes.add( aChild );
  }
  
  public ArrayList<TSW_AbilityNode> getChildNodes()
  {
    return new ArrayList<TSW_AbilityNode>( childNodes );
  }
  
  
  protected TSW_UIControl_AbilityNode createAssociatedUIControl()
  {
    return null;
  }
}


class TSW_AbilityBranch extends TSW_AbilityNode
{
  ArrayList<TSW_Ability> abilities;

  public TSW_AbilityBranch( String aName )
  {
    super();
    
    name = new String( aName );
  }
  
  
  public TSW_UIControl_AbilityNode createAssociatedUIControl()
  {
    TSW_UIControl_AbilityBranch tControl = new TSW_UIControl_AbilityBranch( this );
    linkedControl = tControl;
    
    return tControl;
  }
}


class TSW_Ability extends TSW_AbilityNode
{
  int points;
  String description;
  
  public int nodeLockedColor;
  public int nodeUnlockedColor;

  public TSW_Ability( String aName, int aPoints )
  {
    // Don't do super(), because this node cannot have children
    
    name = aName;
    points = aPoints;
  }

  public TSW_UIControl_AbilityNode createAssociatedUIControl()
  {
    TSW_UIControl_Ability tControl = new TSW_UIControl_Ability( this );
    linkedControl = tControl;
    
    return tControl;
  }
}
class TSW_AbilityTree_Generated extends TSW_AbilityTree
{
  final int WHEEL_BRANCH_COLOR = color( 0, 0.0f, 0.3f, 0.5f );
  TSW_AbilityTree_ColorSet colorSet_default = new TSW_AbilityTree_ColorSet( WHEEL_BRANCH_COLOR, WHEEL_BRANCH_COLOR, WHEEL_BRANCH_COLOR );
  
  final int MELEE_BRANCH_COLOR = color( 30, 0.6f, 0.6f, 0.5f );
  final int MELEE_ABILITY_LOCKED_COLOR = color( 30, 0.7f, 0.4f, 0.5f );
  final int MELEE_ABILITY_UNLOCKED_COLOR = color( 30, 0.7f, 0.8f, 0.5f );
  TSW_AbilityTree_ColorSet colorSet_melee = new TSW_AbilityTree_ColorSet( MELEE_BRANCH_COLOR, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR );
  
  final int MAGIC_BRANCH_COLOR = color( 210, 0.5f, 0.75f, 0.5f );
  final int MAGIC_ABILITY_LOCKED_COLOR = color( 210, 0.6f, 0.5f, 0.5f );
  final int MAGIC_ABILITY_UNLOCKED_COLOR = color( 210, 0.6f, 0.8f, 0.5f );
  TSW_AbilityTree_ColorSet colorSet_magic = new TSW_AbilityTree_ColorSet( MAGIC_BRANCH_COLOR, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR );
  
  final int RANGED_BRANCH_COLOR = color( 5, 0.45f, 0.7f, 0.5f );
  final int RANGED_ABILITY_LOCKED_COLOR = color( 5, 0.55f, 0.5f, 0.5f );
  final int RANGED_ABILITY_UNLOCKED_COLOR = color( 5, 0.55f, 0.8f, 0.5f );
  TSW_AbilityTree_ColorSet colorSet_ranged = new TSW_AbilityTree_ColorSet( RANGED_BRANCH_COLOR, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR );
  
  final int MISC_BRANCH_COLOR = color( 120, 0.35f, 0.5f, 0.5f );
  final int MISC_ABILITY_COLOR_LOCKED = color( 120, 0.35f, 0.5f, 0.5f );
  final int MISC_ABILITY_COLOR_UNLOCKED = color( 120, 0.35f, 0.8f, 0.5f );
  TSW_AbilityTree_ColorSet colorSet_misc = new TSW_AbilityTree_ColorSet( MISC_BRANCH_COLOR, MISC_ABILITY_COLOR_LOCKED, MISC_ABILITY_COLOR_UNLOCKED );
  
  final int AUX_BRANCH_COLOR = color( 180, 0.3f, 0.6f, 0.5f );
  final int AUX_ABILITY_COLOR_LOCKED = color( 180, 0.3f, 0.33f, 0.5f );
  final int AUX_ABILITY_COLOR_UNLOCKED = color( 180, 0.3f, 0.8f, 0.5f );
  TSW_AbilityTree_ColorSet colorSet_auxiliary = new TSW_AbilityTree_ColorSet( AUX_BRANCH_COLOR, AUX_ABILITY_COLOR_LOCKED, AUX_ABILITY_COLOR_UNLOCKED );


  public TSW_AbilityTree_Generated()
  {
    super();
    
    
  }
  
  public void populate()
  {
    cLevels = 4;
    
    TSW_AbilityBranch tSuperBranch = null;
    TSW_AbilityBranch tMainBranch = null;
    TSW_AbilityBranch tWeaponBranch = null;
    TSW_AbilityBranch tMinorBranch = null;
    TSW_Ability tAbility = null;
    
    tSuperBranch = addNewBranch( "Main", WHEEL_BRANCH_COLOR, null );
    {
      tMainBranch = addNewBranch( "Melee", MELEE_BRANCH_COLOR, tSuperBranch );
      {
        tWeaponBranch = addNewBranch( "Blades", MELEE_BRANCH_COLOR, tMainBranch );
        {
          tMinorBranch = addNewBranch( "Method", MELEE_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "Delicate Strike", 1, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Delicate Precision", 1, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Balanced Blade", 1, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Expose Weakness", 2, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Dancing Blade", 3, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Sharp Blades", 4, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Stunning Swirl", 7, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Technique", MELEE_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "Immortal Spirit", 1, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Blade Torrent", 1, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Perfect Storm", 1, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Martial Discipline", 2, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Regeneration", 3, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Surging Blades", 4, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Fluid Defence", 7, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }

          tMinorBranch = addNewBranch( "Wind through Grass", MELEE_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "Grass Cutter", 9, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Twist the Knife", 12, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Chop Shop", 16, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Seven and a Half Samurai", 21, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny Fulfilled", 34, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Four Seasons", 50, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Tearing of Sky", MELEE_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Crossing River's Edge", MELEE_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Running of the Jagged", MELEE_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Sharpening the Senses", MELEE_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "The Cutting Artist", MELEE_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
        }

        tWeaponBranch = addNewBranch( "Hammers", MELEE_BRANCH_COLOR, tMainBranch );
        {
          tMinorBranch = addNewBranch( "Brawn", MELEE_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "DelicateStrike", 1, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DelicatePrecision", 1, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "BalancedBlade", 1, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ExposeWeakness", 2, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DancingBlade", 3, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SharpBlades", 4, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "StunningSwirl", 7, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Grit", MELEE_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "DelicateStrike", 1, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DelicatePrecision", 1, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "BalancedBlade", 1, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ExposeWeakness", 2, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DancingBlade", 3, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SharpBlades", 4, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "StunningSwirl", 7, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          
          tMinorBranch = addNewBranch( "Industrial Action", MELEE_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Brute Force", MELEE_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Excessive Damage", MELEE_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Sledge Factory", MELEE_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Battering Works", MELEE_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Hammer Pit", MELEE_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
        }

        tWeaponBranch = addNewBranch( "Fists", MELEE_BRANCH_COLOR, tMainBranch );
        {
          tMinorBranch = addNewBranch( "Feral", MELEE_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "DelicateStrike", 1, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DelicatePrecision", 1, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "BalancedBlade", 1, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ExposeWeakness", 2, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DancingBlade", 3, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SharpBlades", 4, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "StunningSwirl", 7, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Primal", MELEE_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "DelicateStrike", 1, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DelicatePrecision", 1, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "BalancedBlade", 1, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ExposeWeakness", 2, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DancingBlade", 3, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SharpBlades", 4, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "StunningSwirl", 7, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }

          tMinorBranch = addNewBranch( "The Wilderness", MELEE_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "The Outback", MELEE_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "The Streets", MELEE_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Warming Up", MELEE_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Heat of Battle", MELEE_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Play with Fire", MELEE_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
        }
      }
      
      tMainBranch = addNewBranch( "Turbulence", MISC_BRANCH_COLOR, tSuperBranch );
      {
        tAbility = addNewAbility( "SleightofHand", 9, MISC_ABILITY_COLOR_LOCKED, MISC_ABILITY_COLOR_UNLOCKED, tMainBranch );
        tAbility = addNewAbility( "UnfairAdvantage", 12, MISC_ABILITY_COLOR_LOCKED, MISC_ABILITY_COLOR_UNLOCKED, tMainBranch );
        tAbility = addNewAbility( "TurntheTables", 16, MISC_ABILITY_COLOR_LOCKED, MISC_ABILITY_COLOR_UNLOCKED, tMainBranch );
        tAbility = addNewAbility( "Cannonball", 21, MISC_ABILITY_COLOR_LOCKED, MISC_ABILITY_COLOR_UNLOCKED, tMainBranch );
        tAbility = addNewAbility( "SpeedFreak", 27, MISC_ABILITY_COLOR_LOCKED, MISC_ABILITY_COLOR_UNLOCKED, tMainBranch );
        tAbility = addNewAbility( "Tenacity", 34, MISC_ABILITY_COLOR_LOCKED, MISC_ABILITY_COLOR_UNLOCKED, tMainBranch );
        tAbility = addNewAbility( "LastResort", 50, MISC_ABILITY_COLOR_LOCKED, MISC_ABILITY_COLOR_UNLOCKED, tMainBranch );
      }

      tMainBranch = addNewBranch( "Magic", MAGIC_BRANCH_COLOR, tSuperBranch );
      {
        tWeaponBranch = addNewBranch( "Blood Magic", MAGIC_BRANCH_COLOR, tMainBranch );
        {
          tMinorBranch = addNewBranch( "Profane", MAGIC_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "DelicateStrike", 1, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DelicatePrecision", 1, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "BalancedBlade", 1, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ExposeWeakness", 2, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DancingBlade", 3, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SharpBlades", 4, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "StunningSwirl", 7, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Sacred", MAGIC_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "DelicateStrike", 1, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DelicatePrecision", 1, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "BalancedBlade", 1, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ExposeWeakness", 2, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DancingBlade", 3, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SharpBlades", 4, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "StunningSwirl", 7, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }

          tMinorBranch = addNewBranch( "Malediction", MAGIC_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Transmission", MAGIC_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Possession", MAGIC_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Wetwork", MAGIC_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Chirurgia", MAGIC_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Venamancy", MAGIC_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
        }

        tWeaponBranch = addNewBranch( "Chaos", MAGIC_BRANCH_COLOR, tMainBranch );
        {
          tMinorBranch = addNewBranch( "Theory", MAGIC_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "DelicateStrike", 1, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DelicatePrecision", 1, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "BalancedBlade", 1, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ExposeWeakness", 2, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DancingBlade", 3, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SharpBlades", 4, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "StunningSwirl", 7, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Chance", MAGIC_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "DelicateStrike", 1, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DelicatePrecision", 1, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "BalancedBlade", 1, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ExposeWeakness", 2, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DancingBlade", 3, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SharpBlades", 4, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "StunningSwirl", 7, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }

          tMinorBranch = addNewBranch( "Teorema", MAGIC_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "The Value of x", MAGIC_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Collapse", MAGIC_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Building Blocks", MAGIC_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Shell Game", MAGIC_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "The Fourth Wall", MAGIC_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
        }

        tWeaponBranch = addNewBranch( "Elementalism", MAGIC_BRANCH_COLOR, tMainBranch );
        {
          tMinorBranch = addNewBranch( "Spark", MAGIC_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "DelicateStrike", 1, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DelicatePrecision", 1, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "BalancedBlade", 1, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ExposeWeakness", 2, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DancingBlade", 3, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SharpBlades", 4, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "StunningSwirl", 7, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "React", MAGIC_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "DelicateStrike", 1, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DelicatePrecision", 1, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "BalancedBlade", 1, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ExposeWeakness", 2, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DancingBlade", 3, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SharpBlades", 4, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "StunningSwirl", 7, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }

          tMinorBranch = addNewBranch( "Zero Crossing", MAGIC_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Altered States", MAGIC_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Mortality Curve", MAGIC_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Resonance", MAGIC_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Disturbance", MAGIC_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Tempest", MAGIC_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenandaalfSamurai", 21, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
        }
      }
      
      tMainBranch = addNewBranch( "Subversion", MISC_BRANCH_COLOR, tSuperBranch );
      {
        tAbility = addNewAbility( "SleightofHand", 9, MISC_ABILITY_COLOR_LOCKED, MISC_ABILITY_COLOR_UNLOCKED, tMainBranch );
        tAbility = addNewAbility( "UnfairAdvantage", 12, MISC_ABILITY_COLOR_LOCKED, MISC_ABILITY_COLOR_UNLOCKED, tMainBranch );
        tAbility = addNewAbility( "TurntheTables", 16, MISC_ABILITY_COLOR_LOCKED, MISC_ABILITY_COLOR_UNLOCKED, tMainBranch );
        tAbility = addNewAbility( "Cannonball", 21, MISC_ABILITY_COLOR_LOCKED, MISC_ABILITY_COLOR_UNLOCKED, tMainBranch );
        tAbility = addNewAbility( "SpeedFreak", 27, MISC_ABILITY_COLOR_LOCKED, MISC_ABILITY_COLOR_UNLOCKED, tMainBranch );
        tAbility = addNewAbility( "Tenacity", 34, MISC_ABILITY_COLOR_LOCKED, MISC_ABILITY_COLOR_UNLOCKED, tMainBranch );
        tAbility = addNewAbility( "LastResort", 50, MISC_ABILITY_COLOR_LOCKED, MISC_ABILITY_COLOR_UNLOCKED, tMainBranch );
      }

      tMainBranch = addNewBranch( "Ranged", RANGED_BRANCH_COLOR, tSuperBranch );
      {
        tWeaponBranch = addNewBranch( "Shotgun", RANGED_BRANCH_COLOR, tMainBranch );
        {
          tMinorBranch = addNewBranch( "Enforce", RANGED_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "DelicateStrike", 1, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DelicatePrecision", 1, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "BalancedBlade", 1, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ExposeWeakness", 2, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DancingBlade", 3, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SharBlades", 4, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "StunningSwirl", 7, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Control", RANGED_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "DelicateStrike", 1, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DelicatePrecision", 1, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "BalancedBlade", 1, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ExposeWeakness", 2, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DancingBlade", 3, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SharBlades", 4, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "StunningSwirl", 7, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }

          tMinorBranch = addNewBranch( "Crackdown", RANGED_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenanHalfSamurai", 21, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Restricted Access", RANGED_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenanHalfSamurai", 21, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Close Encounters", RANGED_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenanHalfSamurai", 21, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Securing the Perimeter", RANGED_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenanHalfSamurai", 21, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Hunkering Down", RANGED_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenanHalfSamurai", 21, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Tactical Surprise", RANGED_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenanHalfSamurai", 21, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
        }

        tWeaponBranch = addNewBranch( "Pistols", RANGED_BRANCH_COLOR, tMainBranch );
        {
          tMinorBranch = addNewBranch( "Profane", RANGED_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "DelicateStrike", 1, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DelicatePrecision", 1, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "BalancedBlade", 1, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ExposeWeakness", 2, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DancingBlade", 3, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SharBlades", 4, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "StunningSwirl", 7, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Sacred", RANGED_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "DelicateStrike", 1, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DelicatePrecision", 1, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "BalancedBlade", 1, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ExposeWeakness", 2, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DancingBlade", 3, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SharBlades", 4, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "StunningSwirl", 7, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }

          tMinorBranch = addNewBranch( "Malediction", RANGED_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenanHalfSamurai", 21, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Transmission", RANGED_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenanHalfSamurai", 21, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Possession", RANGED_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenanHalfSamurai", 21, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Wetwork", RANGED_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenanHalfSamurai", 21, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Chirurgia", RANGED_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenanHalfSamurai", 21, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Venamancy", RANGED_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenanHalfSamurai", 21, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
        }

        tWeaponBranch = addNewBranch( "Assault Rifles", RANGED_BRANCH_COLOR, tMainBranch );
        {
          tMinorBranch = addNewBranch( "Profane", RANGED_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "DelicateStrike", 1, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DelicatePrecision", 1, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "BalancedBlade", 1, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ExposeWeakness", 2, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DancingBlade", 3, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SharBlades", 4, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "StunningSwirl", 7, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Sacred", RANGED_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "DelicateStrike", 1, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DelicatePrecision", 1, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "BalancedBlade", 1, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ExposeWeakness", 2, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DancingBlade", 3, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SharBlades", 4, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "StunningSwirl", 7, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }

          tMinorBranch = addNewBranch( "Malediction", RANGED_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenanHalfSamurai", 21, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Transmission", RANGED_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenanHalfSamurai", 21, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Possession", RANGED_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenanHalfSamurai", 21, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Wetwork", RANGED_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenanHalfSamurai", 21, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Chirurgia", RANGED_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenanHalfSamurai", 21, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
          tMinorBranch = addNewBranch( "Venamancy", RANGED_BRANCH_COLOR, tWeaponBranch );
          {
            tAbility = addNewAbility( "GrassCutter", 9, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "TwisttheKnife", 12, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "ChopShop", 16, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "SevenanHalfSamurai", 21, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "Destiny", 27, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "DestinyFulfilled", 34, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
            tAbility = addNewAbility( "FourSeasons", 50, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR, tMinorBranch );
          }
        }
      }

      tMainBranch = addNewBranch( "Survivalism", MISC_BRANCH_COLOR, tSuperBranch );
      {
        tAbility = addNewAbility( "Sleight of Hand", 9, MISC_ABILITY_COLOR_LOCKED, MISC_ABILITY_COLOR_UNLOCKED, tMainBranch );
        tAbility = addNewAbility( "Unfair Advantage", 12, MISC_ABILITY_COLOR_LOCKED, MISC_ABILITY_COLOR_UNLOCKED, tMainBranch );
        tAbility = addNewAbility( "Turn the Tables", 16, MISC_ABILITY_COLOR_LOCKED, MISC_ABILITY_COLOR_UNLOCKED, tMainBranch );
        tAbility = addNewAbility( "Cannonball", 21, MISC_ABILITY_COLOR_LOCKED, MISC_ABILITY_COLOR_UNLOCKED, tMainBranch );
        tAbility = addNewAbility( "Speed Freak", 27, MISC_ABILITY_COLOR_LOCKED, MISC_ABILITY_COLOR_UNLOCKED, tMainBranch );
        tAbility = addNewAbility( "Tenacity", 34, MISC_ABILITY_COLOR_LOCKED, MISC_ABILITY_COLOR_UNLOCKED, tMainBranch );
        tAbility = addNewAbility( "Last Resort", 50, MISC_ABILITY_COLOR_LOCKED, MISC_ABILITY_COLOR_UNLOCKED, tMainBranch );
      }
    }
    
    
    tSuperBranch = addNewBranch( "Auxiliary", WHEEL_BRANCH_COLOR, null );
    {
      tMainBranch = addNewBranch( "Melee", AUX_BRANCH_COLOR, tSuperBranch );
      {
        tWeaponBranch = addNewBranch( "(Locked)", AUX_BRANCH_COLOR, tMainBranch );
        tWeaponBranch = addNewBranch( "Chainsaw", AUX_BRANCH_COLOR, tMainBranch );
        {
          tAbility = addNewAbility( "PopShot", 50, AUX_ABILITY_COLOR_LOCKED, AUX_ABILITY_COLOR_UNLOCKED, tWeaponBranch );
          tAbility = addNewAbility( "Rangefinder", 50, AUX_ABILITY_COLOR_LOCKED, AUX_ABILITY_COLOR_UNLOCKED, tWeaponBranch );
          tAbility = addNewAbility( "Clusterstruck", 50, AUX_ABILITY_COLOR_LOCKED, AUX_ABILITY_COLOR_UNLOCKED, tWeaponBranch );
          tAbility = addNewAbility( "RocketScience", 50, AUX_ABILITY_COLOR_LOCKED, AUX_ABILITY_COLOR_UNLOCKED, tWeaponBranch );
          tAbility = addNewAbility( "DeathFromAbove", 50, AUX_ABILITY_COLOR_LOCKED, AUX_ABILITY_COLOR_UNLOCKED, tWeaponBranch );
          tAbility = addNewAbility( "Warhead", 50, AUX_ABILITY_COLOR_LOCKED, AUX_ABILITY_COLOR_UNLOCKED, tWeaponBranch );
          tAbility = addNewAbility( "Biged Button", 50, AUX_ABILITY_COLOR_LOCKED, AUX_ABILITY_COLOR_UNLOCKED, tWeaponBranch );
        }
        tWeaponBranch = addNewBranch( "(Locked)", AUX_BRANCH_COLOR, tMainBranch );
      }

      tMainBranch = addNewBranch( "Magic", AUX_BRANCH_COLOR, tSuperBranch );
      {
        tWeaponBranch = addNewBranch( "(Locked)", AUX_BRANCH_COLOR, tMainBranch );
        tWeaponBranch = addNewBranch( "Quantum", AUX_BRANCH_COLOR, tMainBranch );
        {
          tAbility = addNewAbility( "PopShot", 50, AUX_ABILITY_COLOR_LOCKED, AUX_ABILITY_COLOR_UNLOCKED, tWeaponBranch );
          tAbility = addNewAbility( "Rangefinder", 50, AUX_ABILITY_COLOR_LOCKED, AUX_ABILITY_COLOR_UNLOCKED, tWeaponBranch );
          tAbility = addNewAbility( "Clusterstruck", 50, AUX_ABILITY_COLOR_LOCKED, AUX_ABILITY_COLOR_UNLOCKED, tWeaponBranch );
          tAbility = addNewAbility( "RocketScience", 50, AUX_ABILITY_COLOR_LOCKED, AUX_ABILITY_COLOR_UNLOCKED, tWeaponBranch );
          tAbility = addNewAbility( "DeathFromAbove", 50, AUX_ABILITY_COLOR_LOCKED, AUX_ABILITY_COLOR_UNLOCKED, tWeaponBranch );
          tAbility = addNewAbility( "Warhead", 50, AUX_ABILITY_COLOR_LOCKED, AUX_ABILITY_COLOR_UNLOCKED, tWeaponBranch );
          tAbility = addNewAbility( "BigRedButton", 50, AUX_ABILITY_COLOR_LOCKED, AUX_ABILITY_COLOR_UNLOCKED, tWeaponBranch );
        }
        tWeaponBranch = addNewBranch( "(Locked)", AUX_BRANCH_COLOR, tMainBranch );
      }

      tMainBranch = addNewBranch( "Ranged", AUX_BRANCH_COLOR, tSuperBranch );
      {
        tWeaponBranch = addNewBranch( "(Locked)", AUX_BRANCH_COLOR, tMainBranch );
        tWeaponBranch = addNewBranch( "Rocket Launcher", AUX_BRANCH_COLOR, tMainBranch );
        {
          tAbility = addNewAbility( "Pop Shot", 50, AUX_ABILITY_COLOR_LOCKED, AUX_ABILITY_COLOR_UNLOCKED, tWeaponBranch );
          tAbility = addNewAbility( "Rangefinder", 50, AUX_ABILITY_COLOR_LOCKED, AUX_ABILITY_COLOR_UNLOCKED, tWeaponBranch );
          tAbility = addNewAbility( "Clusterstruck", 50, AUX_ABILITY_COLOR_LOCKED, AUX_ABILITY_COLOR_UNLOCKED, tWeaponBranch );
          tAbility = addNewAbility( "Rocket Science", 50, AUX_ABILITY_COLOR_LOCKED, AUX_ABILITY_COLOR_UNLOCKED, tWeaponBranch );
          tAbility = addNewAbility( "Death From Above", 50, AUX_ABILITY_COLOR_LOCKED, AUX_ABILITY_COLOR_UNLOCKED, tWeaponBranch );
          tAbility = addNewAbility( "Warhead", 50, AUX_ABILITY_COLOR_LOCKED, AUX_ABILITY_COLOR_UNLOCKED, tWeaponBranch );
          tAbility = addNewAbility( "Big Red Button", 50, AUX_ABILITY_COLOR_LOCKED, AUX_ABILITY_COLOR_UNLOCKED, tWeaponBranch );
        }
        tWeaponBranch = addNewBranch( "(Locked)", AUX_BRANCH_COLOR, tMainBranch );
      }
    }
  }
  
}
class TSW_UIControl_AbilityNode extends UIControl
{
  TSW_UIControl_AbilityTree parentTreeControl;
  TSW_AbilityNode linkedNode;

  public float cThickness;
  public float cStartAngle, cEndAngle, cDistanceFromCenter;
  DampingHelper_Float damper_startAngle, damper_endAngle;

  boolean hoveredInPrevFrame;  
  DampingHelper_Float damper_hoverFactor;
  DampingHelper_Float damper_glowFactor;

  int nodeColor;
  Global_Float nodeGapSize;

  public TSW_UIControl_AbilityNode( TSW_AbilityNode aNode )
  {
    super( new Rectangle() );

    linkedNode = aNode;
    nodeColor = linkedNode.nodeColor;

    hoveredInPrevFrame = false;
  }

  public void setup( TSW_UIControl_AbilityTree aParentTreeControl )
  {
    super.setup();

    parentTreeControl = aParentTreeControl;

    float tDampingFactor = 0.05f;
    
    damper_startAngle = new DampingHelper_Float( tDampingFactor, 0 );
    damper_endAngle = new DampingHelper_Float( tDampingFactor, 0 );

    damper_hoverFactor = new DampingHelper_Float( 0.1f, 0.0f );
    damper_glowFactor = new DampingHelper_Float( 0.1f, 0.0f );

    nodeGapSize = new Global_Float( 0 );
  }

  public void update()
  {
    super.update();

    float tDampingFactor = 0.05f;
    if( parentTreeControl.rotatingByDrag )
    {
      tDampingFactor = 0.3f;
    }
    damper_startAngle.setDampingFactor( tDampingFactor );
    damper_endAngle.setDampingFactor( tDampingFactor );
    
    damper_startAngle.update( cStartAngle );
    damper_endAngle.update( cEndAngle );

    if ( hoveredInPrevFrame != ( this == hoveredControl ) )
    {
      if ( hoveredInPrevFrame )
      {
        // Damp out slowly
        damper_hoverFactor.dampingFactor = 0.2f;
      }
      else
      {
        // Damp in quickly
        damper_hoverFactor.dampingFactor = 0.5f;
      }
    }

    damper_hoverFactor.update( this == hoveredControl ? 1.0f : 0.0f );
    hoveredInPrevFrame = this == hoveredControl;
  }

  public void draw()
  {
    super.draw();

    PVector tCenter = parentTreeControl.getCenterPos();
    float tSize = parentTreeControl.size;

    float tRadius = 0;
    float tArcThickness = cThickness;

    float tDistanceFromCenter = cDistanceFromCenter;
    float tGapSize = nodeGapSize.value;
    float tStartAngle = damper_startAngle.getValue() + tGapSize / tDistanceFromCenter;
    float tEndAngle = damper_endAngle.getValue() - tGapSize / tDistanceFromCenter;

    // Cull if too thin
    float tArcLength = calcArcLength(); 
    if ( tArcLength > 2.0f )
    {
      noFill();
      strokeCap( SQUARE );
      ellipseMode( RADIUS );

      tRadius = tDistanceFromCenter + tArcThickness / 2;

      if( damper_glowFactor.getValue() > EPSILON )
      {
        stroke( hue( nodeColor ), saturation( nodeColor ) + ( ( saturation( nodeColor ) > 0 ) ? ( 1 - saturation( nodeColor ) ) * 0.5f * damper_glowFactor.getValue() : 0 ), 1.0f, alpha( nodeColor ) * brightness( nodeColor ) * 0.4f * damper_glowFactor.getValue() );

        float tOutline = -4;
        strokeWeight( tArcThickness - tOutline );
        arc( tCenter.x, tCenter.y, tRadius, tRadius, tStartAngle - tOutline / tDistanceFromCenter, tEndAngle + tOutline / tDistanceFromCenter, OPEN );     

        tOutline = -2;
        strokeWeight( tArcThickness - tOutline );
        arc( tCenter.x, tCenter.y, tRadius, tRadius, tStartAngle - tOutline / tDistanceFromCenter, tEndAngle + tOutline / tDistanceFromCenter, OPEN );     

        tOutline = 1;
        strokeWeight( tArcThickness - tOutline );
        arc( tCenter.x, tCenter.y, tRadius, tRadius, tStartAngle - tOutline / tDistanceFromCenter, tEndAngle + tOutline / tDistanceFromCenter, OPEN );     

        tOutline = 2;
        strokeWeight( tArcThickness - tOutline );
        arc( tCenter.x, tCenter.y, tRadius, tRadius, tStartAngle - tOutline / tDistanceFromCenter, tEndAngle + tOutline / tDistanceFromCenter, OPEN );
      }

      int tNodeColor = nodeColor;

      strokeWeight( tArcThickness );
      tNodeColor = color( hue( nodeColor ), saturation( nodeColor ), brightness( nodeColor ), alpha( nodeColor ) );
      stroke( tNodeColor );

      arc( tCenter.x, tCenter.y, tRadius, tRadius, tStartAngle, tEndAngle, OPEN );
    }
    else
    {
      noFill();
      strokeCap( SQUARE );
      
      float tAlphaFactor = min( 0.4f + tArcLength * 0.4f, 1.0f );
      int tNodeColor = color( hue( nodeColor ), saturation( nodeColor ), brightness( nodeColor ), alpha( nodeColor ) * tAlphaFactor );
      
      strokeWeight( max( tArcLength, 1.0f ) );
      stroke( tNodeColor );

      float tMidAngle = Angle.calcMidAngle( tStartAngle, tEndAngle );
      PVector tStartPoint = new PVector( tCenter.x, tCenter.y );
      PVector tEndPoint = new PVector( tCenter.x, tCenter.y );
      tStartPoint.x += tDistanceFromCenter * cos( tMidAngle );
      tStartPoint.y += tDistanceFromCenter * sin( tMidAngle );
      tEndPoint.x += ( tDistanceFromCenter + tArcThickness ) * cos( tMidAngle );
      tEndPoint.y += ( tDistanceFromCenter + tArcThickness ) * sin( tMidAngle );
      
      line( tStartPoint.x, tStartPoint.y, tEndPoint.x, tEndPoint.y );
    }
  }



  public boolean isMouseIn()
  {
    // Cull if too thin
    if ( damper_endAngle.getValue() - damper_startAngle.getValue() >= 1 / cDistanceFromCenter )
    {
      PVector tCenter = parentTreeControl.getCenterPos();  

      float tDist = tCenter.dist( new PVector( mouseX, mouseY ) );

      if ( tDist >= cDistanceFromCenter && tDist <= cDistanceFromCenter + cThickness )
      {
        float tRelativeAngle = atan2( mouseY - tCenter.y, mouseX - tCenter.x );
//        float tOffsetAngle = angleOffset.value;
//        if ( global_lineMode.value ) { 
//          tOffsetAngle = -parentTreeControl.getCenterPos().x / parentTreeControl.getSize();
//        }
//        while ( tRelativeAngle < 0 + tOffsetAngle ) { 
//          tRelativeAngle += TWO_PI;
//        }

        return Angle.isWithinAngles( tRelativeAngle, damper_startAngle.getValue(), damper_endAngle.getValue() );
      }
    }

    return false;
  }

  public PVector calcArcCenter()
  {
    float tMidAngle = Angle.calcMidAngle( damper_startAngle.getValue(), damper_endAngle.getValue() );
    PVector tArcCenter = parentTreeControl.getCenterPos();
    tArcCenter.x += ( cDistanceFromCenter + cThickness / 2 ) * cos( tMidAngle );
    tArcCenter.y += ( cDistanceFromCenter + cThickness / 2 ) * sin( tMidAngle );

    return tArcCenter;
  }

  public float calcArcLength()
  {
    float tArcLength = cDistanceFromCenter * ( damper_endAngle.getValue() ) - cDistanceFromCenter * ( damper_startAngle.getValue() ) - nodeGapSize.value * 2;
    return tArcLength;
  }
}


class TSW_UIControl_AbilityBranch extends TSW_UIControl_AbilityNode
{
  public TSW_UIControl_AbilityBranch( TSW_AbilityBranch aBranch )
  {
    super( aBranch );
  }

  public void setup( TSW_UIControl_AbilityTree aParentTreeControl )
  {
    super.setup( aParentTreeControl );
    
    nodeGapSize = branchGapSize;
  }

  public void update()
  {
    super.update();

    cThickness = ringThickness.value;
    
    float tGlow = 0.0f;
    if( this == parentTreeControl.selectedAbilityBranch )
    {
      tGlow = 0.667f;
    }
    if( this == hoveredControl )
    {
      tGlow = 1.0f;
    }
    
    damper_glowFactor.update( tGlow );
  }

  public void draw()
  {
    super.draw();

    noStroke();
    textFont( font_TSW_AbilityTree );

    float tFullAlphaLength = 300;
    float tStartFadeInLength = 75;      

    float tArcLength = calcArcLength(); 
    if ( tArcLength >= tStartFadeInLength || damper_hoverFactor.getValue() > EPSILON )
    {
      PVector tArcCenter = calcArcCenter();

      float tAlpha = 0.5f;
      if ( tArcLength < tFullAlphaLength && this != hoveredControl )
      {
        tAlpha = 0.5f * ( tArcLength - tStartFadeInLength ) / ( tFullAlphaLength - tStartFadeInLength );
      }
      tAlpha += ( 1 - tAlpha ) * damper_hoverFactor.getValue();

      if ( tAlpha >= EPSILON )
      {
        textAlign( CENTER, CENTER );
        fill( 0, 0, 1, tAlpha );
        text( linkedNode.name, tArcCenter.x, tArcCenter.y );
      }
    }
  }

  public void onMouseReleased()
  {
    super.onMouseReleased();
    
    if ( parentTreeControl.selectedAbilityBranch != this )
    {
      parentTreeControl.selectedAbilityBranch = this;
    }
    else
    {
      parentTreeControl.selectedAbilityBranch = null;
    }
  }
}

class TSW_UIControl_Ability extends TSW_UIControl_AbilityNode
{
  boolean unlocked;

  public TSW_UIControl_Ability( TSW_Ability aAbility )
  {
    super( aAbility );
  }

  public void setup( TSW_UIControl_AbilityTree aParentTreeControl )
  {
    super.setup( aParentTreeControl );
    
    nodeGapSize = abilityGapSize;
  }
  
  public void update()
  {
    super.update();

    if ( parentTreeControl.isAbilitySelected( this ) )
    {
      cThickness = abilityRingThickness.value * 1.66f;
    }
    else
    {
      cThickness = abilityRingThickness.value;
      //cThickness = abilityRingThickness.value * 0.2 + tLinkedAbilityNode.points;
    }
  }

  public void draw()
  {
    super.draw();

    noStroke();
    textFont( font_TSW_AbilityName );

    float tFullAlphaLength = 300;
    float tStartFadeInLength = 75;      

    PVector tArcCenter = calcArcCenter();
    float tArcLength = calcArcLength(); 

    if ( parentTreeControl.isAbilitySelected( this ) || damper_hoverFactor.getValue() > EPSILON )
    {
      PVector tTextAttachPoint = new PVector( tArcCenter.x, tArcCenter.y );
      float tMidAngle = ( damper_startAngle.getValue() + damper_endAngle.getValue() ) / 2.0f;
      float tTextDistanceFromArc = cThickness / 2 + 10;

      tTextAttachPoint.x += tTextDistanceFromArc * cos( tMidAngle );
      tTextAttachPoint.y += tTextDistanceFromArc * sin( tMidAngle );

      if( global_debug )
      {
        noFill();
        stroke( 0, 0, 0.3f );
        strokeCap( SQUARE );
        strokeWeight( 1 );
        pointcross( tTextAttachPoint.x, tTextAttachPoint.y, 10 );
      }

      textFont( font_TSW_AbilityName );
      PVector tTextDimensions = new PVector( textWidth( ( (TSW_Ability)linkedNode ).name ) + EPSILON, textAscent() + textDescent() + EPSILON   );

      PVector tTextCenter = new PVector( tTextAttachPoint.x, tTextAttachPoint.y );
      tTextCenter.x += 0.5f * tTextDimensions.x * ( min_abs( sqrt(2) * cos( tMidAngle ), signof( cos( tMidAngle ) ) ) );
      tTextCenter.y += 0.5f * tTextDimensions.y * ( min_abs( sqrt(2) * sin( tMidAngle ), signof( sin( tMidAngle ) ) ) );

      float tAlpha = damper_hoverFactor.getValue();
      if( parentTreeControl.isAbilitySelected( this ) ) { tAlpha = 1.0f ; }

      rectMode( CENTER );
      textAlign( LEFT, TOP );
      fill( 0, 0, 1, tAlpha );
      text( ( (TSW_Ability)linkedNode ).name, tTextCenter.x, tTextCenter.y, tTextDimensions.x, tTextDimensions.y );

      if( global_debug )
      {
        noFill();
        stroke( 0, 0, 0.3f );
        strokeCap( SQUARE );
        strokeWeight( 1 );
        rect( tTextCenter.x, tTextCenter.y, tTextDimensions.x, tTextDimensions.y );
      }

      //if( tArcLength > 30 )
      {
//        PVector tDescriptionTopLeft = new PVector( tTextCenter.x, tTextCenter.y );
//        tDescriptionTopLeft.x += 0.5 * tTextDimensions.x + 10;
//        tDescriptionTopLeft.y -= 0.5 * tTextDimensions.y;
//        rectMode( CORNER );
//        textFont( font_TSW_AbilityDescription );
//        text( ( (TSW_Ability)linkedNode ).description, tDescriptionTopLeft.x, tDescriptionTopLeft.y, 200, 100 );

        float tMargin = 3;
        PVector tDescriptionAttachPoint = new PVector( tTextAttachPoint.x, tTextAttachPoint.y );
        tDescriptionAttachPoint.x += tTextDimensions.x * ( min_abs( sqrt(2) * cos( tMidAngle ), signof( cos( tMidAngle ) ) ) ) + signof( cos( tMidAngle ) ) * tMargin;
        tDescriptionAttachPoint.y += tTextDimensions.y * ( min_abs( sqrt(2) * sin( tMidAngle ), signof( sin( tMidAngle ) ) ) ) + signof( sin( tMidAngle ) ) * tMargin;
        
        // DEBUG DescriptionAttachPoint
//        noFill();
//        stroke( 0, 0, 0.3 );
//        strokeCap( SQUARE );
//        strokeWeight( 1 );
//        pointcross( tDescriptionAttachPoint.x, tDescriptionAttachPoint.y, 10 );
        
        PVector tDescriptionDimensions = new PVector( 200, 100 );
        PVector tDescriptionCenter = new PVector( tDescriptionAttachPoint.x, tDescriptionAttachPoint.y );
        tDescriptionCenter.x += 0.5f * tDescriptionDimensions.x * ( min_abs( sqrt(2) * cos( tMidAngle ), signof( cos( tMidAngle ) ) ) );
        tDescriptionCenter.y += 0.5f * tDescriptionDimensions.y * ( min_abs( sqrt(2) * sin( tMidAngle ), signof( sin( tMidAngle ) ) ) );

        PVector tTextHalfDimensions = new PVector(); PVector.mult( tTextDimensions, 0.5f, tTextHalfDimensions );
        PVector tTextTopLeft = new PVector(); PVector.sub( tTextCenter, tTextHalfDimensions, tTextTopLeft );
        PVector tTextBottomRight = new PVector(); PVector.add( tTextCenter, tTextHalfDimensions, tTextBottomRight );

        PVector tDescriptionHalfDimensions = new PVector(); PVector.mult( tDescriptionDimensions, 0.5f, tDescriptionHalfDimensions );
        PVector tDescriptionTopLeft = new PVector(); PVector.sub( tDescriptionCenter, tDescriptionHalfDimensions, tDescriptionTopLeft );
        PVector tDescriptionBottomRight = new PVector(); PVector.add( tDescriptionCenter, tDescriptionHalfDimensions, tDescriptionBottomRight );

        int tTextHAlign = LEFT;
        int tTextVAlign = TOP;
        if( tDescriptionCenter.x < tTextCenter.x && !global_lineMode.value )
        {
          tTextHAlign = RIGHT;  
        }
        if( tDescriptionTopLeft.y < tTextTopLeft.y && tDescriptionBottomRight.y > tTextBottomRight.y )
        {
          tTextVAlign = CENTER;
        }
        else if( tDescriptionTopLeft.y < tTextTopLeft.y )
        {
          tTextVAlign = BOTTOM;
        }

        textAlign( tTextHAlign, tTextVAlign );
        textFont( font_TSW_AbilityDescription );
        text( ( (TSW_Ability)linkedNode ).description, tDescriptionCenter.x, tDescriptionCenter.y, 200, 100 + ( textAscent() + textDescent() ) * 2.5f + textDescent() );

        // DEBUG Box around description
//        noFill();
//        stroke( 0, 0, 0.3 );
//        strokeCap( SQUARE );
//        strokeWeight( 1 );
//        rect( tDescriptionCenter.x, tDescriptionCenter.y, tDescriptionDimensions.x, tDescriptionDimensions.y );
      }



      rectMode( CORNER );
    }
  }

  public void onMouseReleased()
  {
    if ( !parentTreeControl.isAbilitySelected( this ) )
    {
      parentTreeControl.selectAbility( this );
    }
    else
    {
      parentTreeControl.unselectAbility( this );
    }

    unlocked = !unlocked;

    TSW_Ability tLinkedAbilityNode = ( (TSW_Ability)linkedNode ); 
    nodeColor = unlocked ? tLinkedAbilityNode.nodeUnlockedColor : tLinkedAbilityNode.nodeLockedColor;
  }
}

class TSW_UIControl_AbilityTree extends UIControl
{
  TSW_AbilityTree abilityTree;
  
  TSW_UIControl_AbilityBranch selectedAbilityBranch;
  private ArrayList<TSW_UIControl_Ability> selectedAbilities;  
  
  private PVector centerPos;
  float size;

  int tGrandTotalSize = 1;

  
  boolean rotatingByDrag;
  float mouseDownAngleOffset;
  float mousePressedAngle;
  
  
  private EasingHelper_PVector easingHelper_centerPos;
  private EasingHelper_Float easingHelper_size;
  
  private boolean cLineModeSwitch_PrevValue;
  
  public TSW_UIControl_AbilityTree( TSW_AbilityTree aAbilityTree, Rectangle aRect )
  {
    super( aRect );
    
    abilityTree = aAbilityTree;
    
    selectedAbilityBranch = null;
    selectedAbilities = new ArrayList<TSW_UIControl_Ability>();
    
    centerPos = new PVector( rect.x + rect.width / 2.0f, rect.y + rect.height / 2.0f );
    size = 1;
    
    rotatingByDrag = false;
    mouseDownAngleOffset = 0;
    mousePressedAngle = 0;
  }
  
  public void setup()
  {
    super.setup();
    
    size = outerRingSize.value;

    createControlsForChildAbilityNodes( abilityTree.rootNode ); 
    
    float tDampingFactor = 0;

    easingHelper_centerPos = new EasingHelper_PVector( centerPos );
    easingHelper_size = new EasingHelper_Float( size );
  }
  
  public void update()
  {
    super.update();
    
    if( global_lineMode.value != cLineModeSwitch_PrevValue )
    {
      float tTransitionTime = 2;
      easingHelper_centerPos.start( easingHelper_centerPos.getValue(), tTransitionTime );
      easingHelper_size.start( easingHelper_size.getValue(), tTransitionTime );
    } 
    cLineModeSwitch_PrevValue = global_lineMode.value;
    
    if( global_lineMode.value )
    {
      size = 10000;
      
      centerPos.x = height / 2 + 100;
      //centerPos.x = 200;
      centerPos.y = height * 0.65f + size;
    }
    else
    {
      centerPos.x = height / 2 + 100;
      centerPos.y = height / 2;
      
      if( outerRingSize != null )
      {
        size = outerRingSize.value;
      }
      else
      {
        size = 100;
      }
      easingHelper_size.currentValue = size;
    }
    
    easingHelper_centerPos.update( centerPos );
    easingHelper_size.update( size );

    PVector tDampedCenterPos = getCenterPos();
    float tDampedSize = getSize();

    rect.setRect( tDampedCenterPos.x - tDampedSize, tDampedCenterPos.y - tDampedSize, tDampedSize * 2, tDampedSize * 2 );
    
    if( mousePressedPos != null )
    {
      if( !rotatingByDrag )
      {
        if( mousePressedPos.x != mouseX && mousePressedPos.y != mouseY )
        {
          rotatingByDrag = true;
        }
      }
    }
    
    if( rotatingByDrag )
    {
      float tCurrentMouseDownAngle = atan2( mouseY - centerPos.y, mouseX - centerPos.x ) + TWO_PI;
      
      float tNewAngleOffset = mouseDownAngleOffset + ( tCurrentMouseDownAngle - mousePressedAngle );
      while( tNewAngleOffset > angleOffset.value + PI )
      {
        tNewAngleOffset -= TWO_PI;
      }
      while( tNewAngleOffset < angleOffset.value - PI )
      {
        tNewAngleOffset += TWO_PI;
      }
      angleOffset.value = tNewAngleOffset;
    }
    
    float tAngleOffset = angleOffset.value;
    float tWheelStartAngle = 0 + tAngleOffset;
    float tWheelEndAngle = TWO_PI + tAngleOffset;
    
    if( global_lineMode.value )
    {
      tWheelStartAngle = -tDampedCenterPos.x / tDampedSize - HALF_PI;
      tWheelEndAngle = ( width - tDampedCenterPos.x ) / tDampedSize - HALF_PI;
    }
    
    updateChildNodeDimensions( abilityTree.rootNode, 0, tWheelStartAngle, tWheelEndAngle );
  }
  
  public void draw()
  {
    super.draw();
    
    PVector tCenter = getCenterPos();

    fill( 0, 0, 0.7f );
    noStroke();
    
    textAlign( CENTER, BOTTOM );
    textFont( font_TSW_Title );
    text( "THE SECRET WORLD", tCenter.x, tCenter.y - 30 );

    textFont( font_TSW_Subtitle );
    text( "ABILITY WHEEL", tCenter.x, tCenter.y - 5 );

    fill( 0, 0, 0.3f );
    textAlign( CENTER, TOP );
    textFont( font_TSW_Subtitle );
    text( "Visualisation Test", tCenter.x, tCenter.y + 5 );

    if( global_debug )
    {
      noFill();
      stroke( 0, 0, 0.3f );
      strokeCap( SQUARE );
      strokeWeight( 1 );
      
      float tCrossSize = 10;
      pointcross( tCenter.x, tCenter.y, tCrossSize );
      
      //if( this == hoveredControl ) { stroke( 0, 0, 0.4 ); }
      
      ellipseMode( RADIUS );
      ellipse( tCenter.x, tCenter.y, rect.width / 2.0f, rect.height / 2.0f );    
    }

    if( selectedAbilityBranch != null )
    {
//      float tGlowRadius = outerRingSize.value - ringThickness.value * 6;
//      strokeWeight( ringThickness.value * 15 );
//      stroke( hue( selectedAbilityNode.nodeColor ), 0.1, 0.3, 0.1 );
//      arc( tCenter.x, tCenter.y, tGlowRadius, tGlowRadius, PI + HALF_PI + selectedAbilityNode.linkedControl.damper_startAngle.getValue(), PI + HALF_PI + selectedAbilityNode.linkedControl.damper_endAngle.getValue(), OPEN );     
    }
  }
  
  
  
  public boolean isMouseIn()
  {
    float tXDiff = mouseX - ( rect.x + rect.width / 2.0f );
    float tYDiff = mouseY - ( rect.y + rect.height / 2.0f );
    float tSquaredLength = ( tXDiff * tXDiff ) + ( tYDiff * tYDiff );
    float tRectRadius = ( rect.width / 2.0f ) * ( rect.width / 2.0f );
    
    if( tSquaredLength <= tRectRadius ) { return true; }
    return false;
  }
  
  public void onMousePressed()
  {
    super.onMousePressed();
    
    mousePressedAngle = atan2( mouseY - centerPos.y, mouseX - centerPos.x ) + TWO_PI;
    mouseDownAngleOffset = angleOffset.value;
  }
  
  public void onMouseReleased()
  {
    super.onMouseReleased();
    
    //angleOffset.value = Angle.normalize( angleOffset.value );
    //normalizeAngles( abilityTree.rootNode );
    
    if( !rotatingByDrag )
    {
      selectedAbilityBranch = null;
    }
    
    rotatingByDrag = false;
  }
  
  
  
  private void loadAbilityTree( TSW_AbilityTree aAbilityTree )
  {
    abilityTree = aAbilityTree;
  }
  
  
  private void createControlsForChildAbilityNodes( TSW_AbilityNode aNode )
  {
    for( TSW_AbilityNode iNode : aNode.getChildNodes() )
    {
      TSW_UIControl_AbilityNode tControl = iNode.createAssociatedUIControl();
      uiControls.add( tControl );
      
      tControl.setup( this );
      
      if( iNode.getChildNodes().size() > 0 )
      {
          createControlsForChildAbilityNodes( iNode );
      }
    }
  }
  
  
  
  public void selectAbility( TSW_UIControl_Ability aAbility )
  {
    if( !isAbilitySelected( aAbility ) )
    {
      selectedAbilities.add( aAbility );
    }
  }
  
  public void unselectAbility( TSW_UIControl_Ability aAbility )
  {
    selectedAbilities.remove( aAbility );
  } 
  
  public boolean isAbilitySelected( TSW_UIControl_Ability aAbility )
  {
    if( selectedAbilities.indexOf( aAbility ) > -1 )
    {
      return true;
    }
    
    return false;
  }
  
  
  private void updateChildNodeDimensions( TSW_AbilityNode aNode, int aLevel, float aStartAngle, float aEndAngle )
  {
    HashMap<TSW_AbilityNode, Integer> tNodeToRelativeSize = new HashMap<TSW_AbilityNode, Integer>(); 
    int tTotalSize = 0;
    
    for( TSW_AbilityNode iNode : aNode.getChildNodes() )
    {
      int tRelativeSize = getNodeRelativeSize( iNode.linkedControl );
      tNodeToRelativeSize.put( iNode, tRelativeSize );
      tTotalSize += tRelativeSize;
    }

    float tSize = getSize();

    float tOuterRingRadius = tSize - ringThickness.value;
    float tInnerRingRadius = tOuterRingRadius - innerRingSize.value;
    if( global_lineMode.value )
    {
    }

    float tCurrentAngle = aStartAngle;
    for( TSW_AbilityNode iNode : aNode.getChildNodes() )
    {
      TSW_UIControl_AbilityNode tControl = iNode.linkedControl;
      
      tControl.cDistanceFromCenter = ( aLevel * 1.0f / abilityTree.cLevels ) * ( tOuterRingRadius - tInnerRingRadius ) + tInnerRingRadius;

      if( tControl instanceof TSW_UIControl_Ability ) { tControl.cDistanceFromCenter -= ( tOuterRingRadius - tInnerRingRadius ) / abilityTree.cLevels - ringThickness.value - abilityGapSize.value; }

      float tGapSize = branchGapSize.value;
      if( aNode == abilityTree.rootNode ) { tGapSize = 0; }
      if( !showAuxWheel.value && iNode.name.equals( "Main" ) ) { tGapSize = 0; }
      tGapSize /= tControl.cDistanceFromCenter;

//      tControl.cStartAngle = tCurrentAngle + tGapSize / tControl.cDistanceFromCenter;
//      tCurrentAngle = tCurrentAngle + ( aEndAngle - aStartAngle ) * tNodeToRelativeSize.get( iNode ) / tTotalSize;
//      tControl.cEndAngle = tCurrentAngle - tGapSize / tControl.cDistanceFromCenter;

      tControl.cStartAngle = tCurrentAngle;
      tCurrentAngle = tCurrentAngle + ( aEndAngle - aStartAngle ) * tNodeToRelativeSize.get( iNode ) / tTotalSize;
      tControl.cEndAngle = tCurrentAngle;
      
      if( iNode.getChildNodes().size() > 0 )
      {
          updateChildNodeDimensions( iNode, aLevel + 1, tControl.cStartAngle + tGapSize, tControl.cEndAngle - tGapSize );
      }
    }
  }
  
  private int getNodeRelativeSize( TSW_UIControl_AbilityNode aNode )
  {
    int tRelativeSize = 0;

    if( aNode.linkedNode.getChildNodes().size() > 0 )
    {
      for( TSW_AbilityNode iNode : aNode.linkedNode.getChildNodes() )
      {
        tRelativeSize += getNodeRelativeSize( iNode.linkedControl );
      }
    }
    else
    {
      tRelativeSize = 1;
      if( aNode instanceof TSW_UIControl_AbilityNode )
      {
        if( sizeByPoints.value )
        {
          tRelativeSize = ( (TSW_Ability)( aNode.linkedNode ) ).points;
        }
      }
    }
    
    if( selectedAbilityBranch == aNode )
    {
      tRelativeSize = sizeByPoints.value ? round( 11025 / ( 1 - selectedNodeRatio.value ) ) : round( ( 525 + 6 ) / ( 1 - selectedNodeRatio.value ) );
    }
    
    if( aNode.linkedNode.name.equals( "Auxiliary" ) && !showAuxWheel.value )
    {
      tRelativeSize = 0;
    }

    return tRelativeSize;
  }
  
  
  public PVector getCenterPos()
  {
    PVector tCenterPos = easingHelper_centerPos.getValue();
    return tCenterPos;
  }
  
  public float getSize()
  {
    return easingHelper_size.getValue();
  }
  
  
  
  public void normalizeAngles( TSW_AbilityNode aNode )
  {
    TSW_UIControl_AbilityNode tControl = aNode.linkedControl;
    if( tControl != null )
    {
      tControl.damper_startAngle.currentValue += Angle.normalize( tControl.cStartAngle ) - tControl.cStartAngle;
      tControl.damper_endAngle.currentValue += Angle.normalize( tControl.cEndAngle ) - tControl.cEndAngle;
      tControl.cStartAngle = Angle.normalize( tControl.cStartAngle );
      tControl.cEndAngle = Angle.normalize( tControl.cEndAngle );
    }
    
    for( TSW_AbilityNode iNode : aNode.getChildNodes() )
    {
      normalizeAngles( iNode );
    }
  }
}


class TSW_AbilityTree_ColorSet
{
  int branch;
  int ability_locked;
  int ability_unlocked;
  
  public TSW_AbilityTree_ColorSet( int aBranch, int aAbility_Locked, int aAbility_Unlocked )
 {
   branch = aBranch;
   ability_locked = aAbility_Locked;
   ability_unlocked = aAbility_Unlocked;
 } 
}



class TSW_WikiParser
{
  final int WHEEL_BRANCH_COLOR = color( 0, 0.0f, 0.3f, 0.5f );
  TSW_AbilityTree_ColorSet colorSet_default = new TSW_AbilityTree_ColorSet( WHEEL_BRANCH_COLOR, WHEEL_BRANCH_COLOR, WHEEL_BRANCH_COLOR );
  
  final int MELEE_BRANCH_COLOR = color( 30, 0.6f, 0.6f, 0.5f );
  final int MELEE_ABILITY_LOCKED_COLOR = color( 30, 0.7f, 0.4f, 0.5f );
  final int MELEE_ABILITY_UNLOCKED_COLOR = color( 30, 0.7f, 0.8f, 0.5f );
  TSW_AbilityTree_ColorSet colorSet_melee = new TSW_AbilityTree_ColorSet( MELEE_BRANCH_COLOR, MELEE_ABILITY_LOCKED_COLOR, MELEE_ABILITY_UNLOCKED_COLOR );
  
  final int MAGIC_BRANCH_COLOR = color( 210, 0.5f, 0.75f, 0.5f );
  final int MAGIC_ABILITY_LOCKED_COLOR = color( 210, 0.6f, 0.5f, 0.5f );
  final int MAGIC_ABILITY_UNLOCKED_COLOR = color( 210, 0.6f, 0.8f, 0.5f );
  TSW_AbilityTree_ColorSet colorSet_magic = new TSW_AbilityTree_ColorSet( MAGIC_BRANCH_COLOR, MAGIC_ABILITY_LOCKED_COLOR, MAGIC_ABILITY_UNLOCKED_COLOR );
  
  final int RANGED_BRANCH_COLOR = color( 5, 0.45f, 0.7f, 0.5f );
  final int RANGED_ABILITY_LOCKED_COLOR = color( 5, 0.55f, 0.5f, 0.5f );
  final int RANGED_ABILITY_UNLOCKED_COLOR = color( 5, 0.55f, 0.8f, 0.5f );
  TSW_AbilityTree_ColorSet colorSet_ranged = new TSW_AbilityTree_ColorSet( RANGED_BRANCH_COLOR, RANGED_ABILITY_LOCKED_COLOR, RANGED_ABILITY_UNLOCKED_COLOR );
  
  final int MISC_BRANCH_COLOR = color( 120, 0.35f, 0.5f, 0.5f );
  final int MISC_ABILITY_COLOR_LOCKED = color( 120, 0.35f, 0.5f, 0.5f );
  final int MISC_ABILITY_COLOR_UNLOCKED = color( 120, 0.35f, 0.8f, 0.5f );
  TSW_AbilityTree_ColorSet colorSet_misc = new TSW_AbilityTree_ColorSet( MISC_BRANCH_COLOR, MISC_ABILITY_COLOR_LOCKED, MISC_ABILITY_COLOR_UNLOCKED );
  
  final int AUX_BRANCH_COLOR = color( 180, 0.3f, 0.6f, 0.5f );
  final int AUX_ABILITY_COLOR_LOCKED = color( 180, 0.3f, 0.33f, 0.5f );
  final int AUX_ABILITY_COLOR_UNLOCKED = color( 180, 0.3f, 0.8f, 0.5f );
  TSW_AbilityTree_ColorSet colorSet_auxiliary = new TSW_AbilityTree_ColorSet( AUX_BRANCH_COLOR, AUX_ABILITY_COLOR_LOCKED, AUX_ABILITY_COLOR_UNLOCKED );


  TSW_WikiParser()
  {
  }
  
  public void populate( TSW_AbilityTree aAbilityTree )
  {
    TSW_AbilityBranch tMainWheel = aAbilityTree.addNewBranch( "Main", WHEEL_BRANCH_COLOR, null );
    TSW_AbilityBranch tAuxiliaryWheel = aAbilityTree.addNewBranch( "Auxiliary", WHEEL_BRANCH_COLOR, null );

    TSW_AbilityBranch tMainMeleeBranch = null;
    TSW_AbilityBranch tMainMagicBranch = null;
    TSW_AbilityBranch tMainRangedBranch = null;

    TSW_AbilityBranch tAuxiliaryMeleeBranch = null;
    TSW_AbilityBranch tAuxiliaryMagicBranch = null;
    TSW_AbilityBranch tAuxiliaryRangedBranch = null;


    aAbilityTree.cLevels = 1;

    
    ArrayList<XML> tFilesToParse = new ArrayList<XML>();
    tFilesToParse.add( loadXML( "Blade abilities - The Secret World Wiki (TSWW).htm" ) );
    tFilesToParse.add( loadXML( "Hammer abilities - The Secret World Wiki (TSWW).htm" ) );
    tFilesToParse.add( loadXML( "Fists abilities - The Secret World Wiki (TSWW).htm" ) );

    tFilesToParse.add( loadXML( "Subversion - The Secret World Wiki (TSWW).htm" ) );

    tFilesToParse.add( loadXML( "Blood Magic abilities - The Secret World Wiki (TSWW).htm" ) );
    tFilesToParse.add( loadXML( "Chaos abilities - The Secret World Wiki (TSWW).htm" ) );
    tFilesToParse.add( loadXML( "Elementalism abilities - The Secret World Wiki (TSWW).htm" ) );

    tFilesToParse.add( loadXML( "Turbulence - The Secret World Wiki (TSWW).htm" ) );

    tFilesToParse.add( loadXML( "Shotgun abilities - The Secret World Wiki (TSWW).htm" ) );
    tFilesToParse.add( loadXML( "Pistols abilities - The Secret World Wiki (TSWW).htm" ) );
    tFilesToParse.add( loadXML( "Assault Rifle abilities - The Secret World Wiki (TSWW).htm" ) );

    tFilesToParse.add( loadXML( "Survivalism - The Secret World Wiki (TSWW).htm" ) );

    tFilesToParse.add( loadXML( "Chainsaw abilities - The Secret World Wiki (TSWW).htm" ) );
    tFilesToParse.add( loadXML( "Quantum abilities - The Secret World Wiki (TSWW).htm" ) );
    tFilesToParse.add( loadXML( "Rocket Launcher abilities - The Secret World Wiki (TSWW).htm" ) );
    
    TSW_AbilityBranch tCurrentBranch = tMainWheel;
    TSW_AbilityTree_ColorSet tColorSet = colorSet_default;
    for( XML iXML : tFilesToParse )
    {
      if( iXML != null )
      {
        XML tElement = iXML.getChildren( "head" )[0];
        tElement = tElement.getChildren( "title" )[0];
        String tBranchName = trim( tElement.getContent() );

        int tSubStringIndex = tBranchName.indexOf( " abilities" );
        if( tSubStringIndex == -1 ) 
        { 
          tSubStringIndex = tBranchName.indexOf( " - " ); 
        }

        tBranchName = tBranchName.substring( 0, tSubStringIndex );

        if( tBranchName.equals( "Chainsaw" ) || tBranchName.equals( "Quantum" ) || tBranchName.equals( "Rocket Launcher" ) )
        {
          tColorSet = colorSet_auxiliary;
          
          if( tBranchName.equals( "Chainsaw" ) )
          {
            if( tAuxiliaryMeleeBranch == null )
            {
              tAuxiliaryMeleeBranch = aAbilityTree.addNewBranch( "Melee", tColorSet.branch, tAuxiliaryWheel );
            }
            
            tCurrentBranch = tAuxiliaryMeleeBranch;
          }
          else if( tBranchName.equals( "Quantum" ) )
          {
            if( tAuxiliaryMagicBranch == null )
            {
              tAuxiliaryMagicBranch = aAbilityTree.addNewBranch( "Magic", tColorSet.branch, tAuxiliaryWheel );
            }
            
            tCurrentBranch = tAuxiliaryMagicBranch;
          }
          else if( tBranchName.equals( "Rocket Launcher" ) )
          {
            if( tAuxiliaryRangedBranch == null )
            {
              tAuxiliaryRangedBranch = aAbilityTree.addNewBranch( "Ranged", tColorSet.branch, tAuxiliaryWheel );
            }
            
            tCurrentBranch = tAuxiliaryRangedBranch;
          }
        }
        else
        {
          if( tBranchName.equals( "Blade" ) || tBranchName.equals( "Hammer" ) || tBranchName.equals( "Fists" ) )
          {
            if( tMainMeleeBranch == null )
            {
              tMainMeleeBranch = aAbilityTree.addNewBranch( "Melee", colorSet_melee.branch, tMainWheel );
            }
            
            tCurrentBranch = tMainMeleeBranch;
            tColorSet = colorSet_melee;
          }
          else if( tBranchName.equals( "Blood Magic" ) || tBranchName.equals( "Chaos" ) || tBranchName.equals( "Elementalism" ) )
          {
            if( tMainMagicBranch == null )
            {
              tMainMagicBranch = aAbilityTree.addNewBranch( "Magic", colorSet_magic.branch, tMainWheel );
            }
            
            tCurrentBranch = tMainMagicBranch;
            tColorSet = colorSet_magic;
          }
          else if( tBranchName.equals( "Shotgun" ) || tBranchName.equals( "Pistols" ) || tBranchName.equals( "Assault Rifle" ) )
          {
            if( tMainRangedBranch == null )
            {
              tMainRangedBranch = aAbilityTree.addNewBranch( "Ranged", colorSet_ranged.branch, tMainWheel );
            }
            
            tCurrentBranch = tMainRangedBranch;
            tColorSet = colorSet_ranged;
          }
          else if( tBranchName.equals( "Subversion" ) || tBranchName.equals( "Turbulence" ) || tBranchName.equals( "Survivalism" ) )
          {
            tCurrentBranch = tMainWheel;
            tColorSet = colorSet_misc;
          }
          else
          {
            tCurrentBranch = null;
            tColorSet = colorSet_default;
          }
        }

        TSW_AbilityBranch tWeaponBranch = null;
        tWeaponBranch = aAbilityTree.addNewBranch( tBranchName, tColorSet.branch, tCurrentBranch );

        tElement = iXML.getChildren( "body" )[0];
        XML tContentElement = recursiveFindElement( tElement, "div", "id", "mw-content-text" );
        
        XML[] tBranches = tContentElement.getChildren();
        
        TSW_AbilityBranch tMinorBranch = null;
        
        int i = 0;
        while( i < tBranches.length )
        {
          if( tBranches[i].getName().equals( "h3" ) )
          {
            tMinorBranch = aAbilityTree.addNewBranch( trim( tBranches[i].getContent() ), tColorSet.branch, tWeaponBranch );
          }
          else if( tBranches[i].getName().equals( "ul" ) )
          {
            if( tMinorBranch == null )
            {
              tMinorBranch = tWeaponBranch;
            }
            
            int tListItemIndex = 0;
            while( tListItemIndex < tBranches[i].getChildCount() )
            {
              XML tAbilityEntry = tBranches[i].getChildren( "li" )[tListItemIndex];
              String tAbilityName = tAbilityEntry.getChildren( "a" )[0].getContent();
  
              XML tAbilityPointsXML = recursiveFindElement( tAbilityEntry, "span", "style", "color:green" );
  
              if( tAbilityPointsXML != null )
              {
                String tAbilityPointsString = tAbilityPointsXML.getContent();
                int tAbilityPoints = PApplet.parseInt( trim( tAbilityPointsString.substring( 0, tAbilityPointsString.length() - 2 ) ) );
  
                TSW_Ability tAbility = aAbilityTree.addNewAbility( tAbilityName, tAbilityPoints, tColorSet.ability_locked, tColorSet.ability_unlocked, tMinorBranch );
                
                XML tDescriptionXML = tAbilityEntry.getChildren( "dl" )[0];
                tAbility.description = tDescriptionXML.getContent();
              }
              
              ++tListItemIndex;
            }
          }

          
          ++i;
        }
      }
    }
    
    aAbilityTree.cLevels = 4;
  }
  
  public XML recursiveFindElement( XML aElement, String aName, String aAttribute, String aID )
  {
    if( aElement.getName().equals( aName ) )
    {
      if( aElement.getString( aAttribute ).equals( aID ) )
      {
        return aElement;
      }
    }
    
    XML tFoundElement = null;
    
    int i = 0;
    while( i < aElement.getChildCount() && tFoundElement == null )
    {
      tFoundElement = recursiveFindElement( aElement.getChild( i ), aName, aAttribute, aID );
      
      ++i;
    }
    
    return tFoundElement;
  }
}
class UIControl
{
  protected Rectangle rect;
  
  protected PVector mousePressedPos;
  
  protected UIControl( Rectangle aRect )
  {
    rect = new Rectangle( aRect );
  }
  
  public void setup() {};
  public void update() {};
  public void draw() {};
  
  public boolean isMouseIn()
  {
    return false;
  }
  
  public void onMousePressed()
  {
    mousePressedPos = new PVector( mouseX, mouseY );
  }
  
  public void onMouseReleased()
  {
    mousePressedPos = null;
  }
}





class UIControl_Slider extends UIControl
{
  protected String label;
  protected float min, max;
  protected float value;
  
  public Global_Float linkedValue;

  Rectangle valueExtents;
  
  public UIControl_Slider( float aMin, float aMax, Rectangle aRect )
  {
    super( aRect );
    
    min = aMin;
    max = aMax;
    value = min;
    
    valueExtents = new Rectangle( rect.x + rect.height - 1, rect.y - 2, rect.width - 2 * ( rect.height - 1 ), rect.height + 2 * 2 );  
  }
  
  
  
  public void setup( Global_Float aLinkedValue )
  {
    super.setup();
    
    linkedValue = aLinkedValue;
    value = linkedValue.value;
  }
  
  public void update()
  {
    super.update();
    
    if( this == activeControl )
    {
      value = min + ( max - min ) * ( mouseX - valueExtents.x ) / ( valueExtents.width );
      
      if( value < min ) { value = min; }
      if( value > max ) { value = max; }
      
      linkedValue.value = value;
    }
  }

  public void draw()
  {
    super.draw();
    
    noStroke();
    fill( 0, 0, 1, 0.15f );
    if( this == hoveredControl || this == activeControl ) { fill( 0, 0, 1, 0.3f ); } 
    
    rect( rect.x, rect.y, rect.width, rect.height, rect.height / 2.0f );
    
    fill( 0, 0, 1 );
    textFont( font_label );
    textAlign( LEFT, BOTTOM );
    text( label, rect.x, rect.y - 2 );
    
    

    float tValueX =  valueExtents.x + valueExtents.width * ( linkedValue.value - min ) / ( max - min );

    fill( 0, 0, 0.6f );
    if( this == hoveredControl || this == activeControl ) { fill( 0, 0, 1 ); }
    
    rect( tValueX - 1, valueExtents.y, 2, valueExtents.height );
    

    textFont( font_value );
    textAlign( LEFT, TOP );
    text( linkedValue.value, tValueX, rect.y + rect.height + 2 );
  }
  
  
  public boolean isMouseIn()
  {
    return rect.contains( mouseX, mouseY );
  }
  
  
  public void setLabel( String aLabel )
  {
    label = aLabel;
  }
}




class UIControl_Switch extends UIControl
{
  protected String label;
  protected float value;
  
  final float switchWidth = 0.55f;
  
  public Global_Boolean linkedValue;
  DampingHelper_Float valueDamper;

  Rectangle valueExtents;
  
  public UIControl_Switch( Rectangle aRect )
  {
    super( aRect );
    
    value = 0.0f;
    
    int tBorder = 3;
    valueExtents = new Rectangle( rect.x + tBorder, rect.y + tBorder, rect.width - tBorder*2 - round( rect.width * switchWidth ), rect.height - tBorder*2 );  
  }
  
  
  
  public void setup( Global_Boolean aLinkedValue )
  {
    super.setup();
    
    linkedValue = aLinkedValue;
    value = linkedValue.value ? 1.0f : 0.0f;
    
    valueDamper = new DampingHelper_Float( 0.3f, value );
  }
  
  public void update()
  {
    super.update();
    
    if( this == activeControl )
    {
      value = ( mouseX - rect.width * switchWidth * 0.5f - valueExtents.x ) * 1.0f / valueExtents.width;
      if( value < 0.0f ) { value = 0.0f; }
      if( value > 1.0f ) { value = 1.0f; }
      
      valueDamper.currentValue = value;
    }
    else
    {
      value = linkedValue.value ? 1.0f : 0.0f;
      
    }
    valueDamper.update( value );

    linkedValue.value = valueDamper.getValue() >= 0.5f;
  }

  public void draw()
  {
    super.draw();
    
    noStroke();
    fill( 0, 0, 1, 0.15f );
    if( this == hoveredControl || this == activeControl ) { fill( 0, 0, 1, 0.3f ); } 
    
    rect( rect.x, rect.y, rect.width, rect.height, rect.height / 2.0f );
    
    fill( 0, 0, 1 );
    textFont( font_label );
    textAlign( LEFT, BOTTOM );
    text( label, rect.x, rect.y - 2 );
    
    
    float tBrightness = 0.6f;
    if( this == hoveredControl || this == activeControl ) { tBrightness = 1; }
    if( !linkedValue.value ) { tBrightness *= 0.5f; }
    fill( 0, 0, 1, tBrightness );

    rect( valueExtents.x + valueDamper.getValue() * valueExtents.width, valueExtents.y, rect.width * switchWidth, valueExtents.height, valueExtents.height / 2.0f );
    

    textFont( font_value );
    textAlign( LEFT, TOP );
    //text( linkedValue.value, tValueX, rect.y + rect.height + 2 );
  }
  
  
  public boolean isMouseIn()
  {
    return rect.contains( mouseX, mouseY );
  }
  
  
  public void setLabel( String aLabel )
  {
    label = aLabel;
  }
}


class UIOverlay
{
  PVector position;
  
  HashMap<UIControl, PVector> controls;
  
  public UIOverlay( PVector aPosition )
  {
    position = aPosition;
    
    controls = new HashMap<UIControl, PVector>(); 
  }
  
  public void addControl( UIControl aControl )
  {
    controls.put( aControl, new PVector( aControl.rect.x - position.x, aControl.rect.y - position.y ) );
  }
  
  
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "SkillTree" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
